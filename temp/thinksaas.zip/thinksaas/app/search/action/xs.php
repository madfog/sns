<?php 
require 'thinksaas/xunsearch-sdk/php/lib/XS.php';
$xs = new XS('demo');
$search = $xs->search; // 搜索对象来自 XS 的属性