<?php 
defined('IN_TS') or die('Access Denied.');
aac('system')->isLogin();
include template("admin/options");