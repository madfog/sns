<?php
defined('IN_TS') or die('Access Denied.');
return array (
  'name' => '消息盒子',
  'version' => '1.2',
  'desc' => 'ImBox消息盒子',
  'url' => 'http://www.thinksaas.cn',
  'email' => 'thinksaas@qq.com',
  'author' => '邱君',
  'author_url' => 'http://www.thinksaas.cn',
  'isoption' => '1',
  'isinstall' => '1',
  'issql' => '0',
  'issystem' => '1',
  'isappnav'	=> '0',
);
?>