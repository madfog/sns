<?php

defined('IN_TS') or die('Access Denied.');
return array(
    'name' => '文章',
    'version' => '1.2',
    'desc' => '文章',
    'url' => 'http://www.thinksaas.cn',
    'email' => 'thinksaas@qq.com',
    'author' => '邱君',
    'author_url' => 'http://www.thinksaas.cn',
    'isoption' => '1',
    'isinstall' => '1',
    'issql' => '1',
    'issystem' => '1',
    'isappnav' => '1',
);
