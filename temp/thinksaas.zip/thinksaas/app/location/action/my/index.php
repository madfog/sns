<?php 
defined ( 'IN_TS' ) or die ( 'Access Denied.' );


$title = '我的同城';
include template('my/index');