<?php 
defined('IN_TS') or die('Access Denied.');

$arrCate = $new['redeem']->findAll('redeem_cate');